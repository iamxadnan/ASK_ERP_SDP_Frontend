const config={
    "url":"http://localhost:2001"//backend url
}
export default config