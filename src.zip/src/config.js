const config={
    "url":"https://asksdperpproject-production.up.railway.app"//backend url
    // "url":"http://localhost:2001"
}
export default config